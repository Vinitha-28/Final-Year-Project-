# Final-yearproject
cloud-industrial-automation
